#!/bin/sh

autoreconf -i
